<?php

return [
    'name' => 'CreditNotes'
];
