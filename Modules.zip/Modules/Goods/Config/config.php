<?php

return [
    'name' => 'Goods'
];
