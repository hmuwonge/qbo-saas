<?php

return [
    'name' => 'Receipts'
];
