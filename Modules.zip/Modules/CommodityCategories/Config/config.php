<?php

return [
    'name' => 'CommodityCategories'
];
