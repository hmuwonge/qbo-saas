<?php

return [
    'name' => 'StockAdjustments'
];
