<?php

return [
    'name' => 'Purchases'
];
