<?php

return [
    'name' => 'AutoSync'
];
