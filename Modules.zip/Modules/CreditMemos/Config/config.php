<?php

return [
    'name' => 'CreditMemos'
];
