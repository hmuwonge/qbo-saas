<?php

return [
    'name' => 'Invoices'
];
