
<footer class="dash-footer">
    <div class="footer-wrapper">
        <div class="py-1">
            <span class="text-muted"> © {{ date('Y') }} {{ config('app.name') }}</span>
        </div>
    </div>
</footer>
