<!-- Datatables -->
<script src="{{asset('vendor/datatable/datatables.min.js')}}"></script>
<script src="{{ asset('vendor/datatable/dataTables.buttons.min.js') }}"></script>
<script src="{{ asset('vendor/datatable/buttons.bootstrap.min.js') }}"></script>
<script src="{{ asset('vendor/datatable/buttons.colVis.min.js') }}"></script>
<script src="{{ asset('vendor/datatable/buttons.server-side.js') }}"></script>
