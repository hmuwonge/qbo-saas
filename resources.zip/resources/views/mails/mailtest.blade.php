@component('mail::message')
{{__('# Introduction')}}

{{__('This Mail For Testing')}}


{{__('Thanks,')}}<br>

{{Utility::getsettings('app_name')}} 

@endcomponent
